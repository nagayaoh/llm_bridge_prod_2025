# Train

* Step 0　conda環境構築
    * [README_install_conda.md](./README_install_conda.md)
* Step 1　シングルノードのファインチューニング＆強化学習
    * [README_single_node_SFT_PPO.md](./README_single_node_SFT_PPO.md)
* Step 2  マルチノードのファインチューニング＆強化学習
    * [README_multi_node_SFT_PPO.md](./README_multi_node_SFT_PPO.md)